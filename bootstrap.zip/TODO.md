# Authentication Fix Plan

## Steps to fix the "View [auth.login] not found" error

### Phase 1: Create React Authentication Components
- [x] Create Login.jsx component
- [x] Create Register.jsx component  
- [ ] Create ForgotPassword.jsx component
- [ ] Create ResetPassword.jsx component
- [ ] Create VerifyEmail.jsx component
- [ ] Create ConfirmPassword.js极 component
- [x] Create InputError.jsx component
- [x] Create InputLabel.jsx component
- [x] Create PrimaryButton.jsx component
- [x] Create TextInput.jsx component

### Phase 2: Update Authentication Controllers
- [x] Update AuthenticatedSessionController to use Inertia responses
- [x] Update RegisteredUserController to use Inertia responses
- [ ] Update PasswordResetLinkController to use Inertia responses
- [ ] Update NewPasswordController to use Inertia responses
- [ ] Update VerifyEmailController to use Inertia responses
- [ ] Update ConfirmablePasswordController to use Inertia responses

### Phase 3: Clean up Blade Templates
- [ ] Remove or move Blade template files from resources/js/Pages/Auth/

### Phase 4: Testing
- [ ] Test login functionality
- [ ] Test registration functionality
- [ ] Test password reset functionality
